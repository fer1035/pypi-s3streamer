'''
# USAGE

# Import modules.
import json
from mklog import WriteLog

# Initiate with empty dictionary.
logger = WriteLog({})

# Collect entries to log.
logger.log('<strkey>', '<value>')
logger.log('<intkey>', <value>)
logger.log('<boolkey>', <True/False>)

# Print out to CloudWatch as accumulated log.
print(json.dumps(logger.text))

'''

class WriteLog(object):

    def __init__(self, text):
        self.text = text
    
    def log(self, key, value):
        self.text[key] = value
