# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['s3streamer']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.25.1,<3.0.0', 'tqdm>=4.54.1,<5.0.0']

setup_kwargs = {
    'name': 's3streamer',
    'version': '2020.2.1.3',
    'description': 'Stream files to AWS S3 using multipart upload with token-based authentication.',
    'long_description': '==============\n**S3Streamer**\n==============\n\nOverview\n--------\n\nA frontend module to upload files to AWS S3 storage. The module supports large files as it chunks them into smaller sizes and recombines them into the original file in the specified S3 bucket.\n\nThe module employs multiprocessing, and there is the option of specifying the size of each chunk as well as how many chunks to send in a single run. The defaults are listed in **Optional Arguments** below.\n\nPrerequisites\n-------------\n\n- An S3 bucket to receive uploads\n- Several AWS Lambda functions to perform backend tasks including authentication and authorization\n\nRequired (Positional) Arguments\n-------------------------------\n\n- Position 1: Authorization code\n- Position 2: Filename (full path to the file)\n- Position 3: Relative path (to root) in the S3 bucket\n\nOptional (Keyword) Arguments\n----------------------------\n\n- parts: Number of multiprocessing parts to send simultaneously (default: 5)\n- partsize: Size of each part in MB (default: 100)\n- tmp: Location of local temporary directory to store temporary files created by the module (default: \'/tmp\')\n- overwrite: Whether to overwrite existing files on S3 (default: \'NO\')\n- purge: Whether to purge the specified file instead of uploading it (default: \'NO\')\n- domain: The domain for visitors to access uploaded files (default: \'https://storage.url\')\n- requrl: The endpoint URL for backend Lambda function (default: \'https://backend.url\')\n- cdnurl: The endpoint URL for CDN cacne purges (default: \'https://cdn.url\')\n\nUsage\n-----\n\nInstallation::\n\n    pip3 install s3streamer\n\n    # or\n\n    python3 -m pip install s3streamer\n\nIn Python3::\n\n    from s3streamer.s3streamer import multipart\n\n    response = multipart(\'mycode\', \'myfile.iso\', \'downloads/drivers\', domain = \'https://mydownload.com\')\n\nIn BASH::\n\n    python3 -c "from s3streamer.s3streamer import multipart; response = multipart(\'mycode\', \'myfile.iso\', \'downloads/drivers\', domain = \'https://mydownload.com\')\n\nThe file will be available at https://mydownload.com/downloads/drivers/myfile.iso.\n\nSpecial Note\n------------\n\nThis module was created to accommodate a very specific need in a very specific organization, hence the multiple component prerequisites. If you\'re interested to use the full solution, the CloudFormation templates to create them are available.\n',
    'author': 'Ahmad Ferdaus Abd Razak',
    'author_email': 'ahmad.ferdaus.abd.razak@ni.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
