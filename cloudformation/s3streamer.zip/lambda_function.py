import os
import json
import time
import ast
import re
import boto3
from botocore.exceptions import ClientError

# Import internal modules.
from mklog import WriteLog #[internal]

# Validation: Check if file exists.
def get_filesize(client, bucket, file):
    response = client.list_objects_v2(
        Bucket = bucket,
        Prefix = file,
    )
    for obj in response.get('Contents', []):
        if obj['Key'] == file:
            return obj['Size']

def lambda_handler(event, context):

    # Initialize.
    try:

        # Initialize logger
        logger = WriteLog({})

        # Send session data to the logs.
        timestamp = time.strftime('%Y-%m-%d:%H-%M-%S')
        logger.log('request_timestamp', timestamp)
        logger.log('request_id', context.aws_request_id)

        # Get and log input from frontend.        
        payload = json.loads(event['body'])
        try:
            ACTION = payload['action']
        except:
            ACTION = None
        try:
            UPLOADID = payload['uploadid']
        except:
            UPLOADID = None
        try:
            PARTNAME = payload['partname']
        except:
            PARTNAME = None
        try:
            PARTNUMBER = payload['partnumber']
        except:
            PARTNUMBER = None
        try:
            OBJECTS = ast.literal_eval(payload['objects'])
        except:
            OBJECTS = None
        try:
            PARTS = ast.literal_eval(payload['parts'])
        except:
            PARTS = None
        try:
            FILESIZE = payload['filesize']
        except:
            FILESIZE = None
        FILENAME = event['queryStringParameters']['filename']
        logger.log('action', ACTION)
        logger.log('filesize', FILESIZE)
        logger.log('filename', FILENAME)

        # Initialize S3 client.
        client = boto3.client('s3', aws_access_key_id = os.environ['IDSECRET'], aws_secret_access_key = os.environ['SECSECRET'], region_name = os.environ['REGION'])
        
        # If purging, ensure that the file actually exists.
        if ACTION == 'purge' and get_filesize(client, os.environ['BUCKET'], FILENAME) == None:
            STATUSCODE = 404
            STATUSTXT = 'Document does not exist and therefore cannot be purged.'
            logger.log( 'status_code', STATUSCODE)
            logger.log( 'status', STATUSTXT)
            print(json.dumps(logger.text))
            return {
                'statusCode': STATUSCODE,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': os.environ['CORS']
                },
                'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
            }

        # Get pre-signed URL.
        if ACTION == 'geturl':
            try:
                response = client.generate_presigned_post(os.environ['BUCKET'], 'tmp/{}'.format(FILENAME), Fields = None, Conditions = None, ExpiresIn = int(os.environ['URLEXPIRY']))
                STATUSCODE = 200
                STATUSTXT = str(response)
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'description', 'Pre-signed URL returned to client.')
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }
            except Exception as e:
                STATUSCODE = 500
                STATUSTXT = str(e)
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }

        # Get pre-signed URL for non-multipart uploads.
        if ACTION == 'geturls':
            try:
                response = client.generate_presigned_post(os.environ['BUCKET'], FILENAME, Fields = None, Conditions = None, ExpiresIn = int(os.environ['URLEXPIRY']))
                STATUSCODE = 200
                STATUSTXT = str(response)
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'description', 'Pre-signed URL returned to client.')
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }
            except Exception as e:
                STATUSCODE = 500
                STATUSTXT = str(e)
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }
        
        # Get Upload ID.
        if ACTION == 'create':
            try:
                response = client.create_multipart_upload(ACL = 'private', Bucket = os.environ['BUCKET'], Key = FILENAME)
                assert response
                STATUSCODE = 200
                STATUSTXT = response['UploadId']
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'description', 'Upload ID returned to client.')
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }
            except Exception as e:
                STATUSCODE = 500
                STATUSTXT = str(e)
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }

        # Add each part to the main document.
        if ACTION == 'add':
            try:
                response = client.upload_part_copy(
                    Bucket = os.environ['BUCKET'],
                    CopySource = {
                        'Bucket': os.environ['BUCKET'],
                        'Key': 'tmp/{}'.format(PARTNAME)
                    },
                    Key = FILENAME,
                    PartNumber = int(PARTNUMBER),
                    UploadId = UPLOADID
                )
                assert response
                STATUSCODE = 200
                STATUSTXT = 'Part added to the main document.'
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }
            except Exception as e:
                STATUSCODE = 500
                STATUSTXT = str(e)
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }
        
        # Complete multipart recombination.
        if ACTION == 'complete':
            try:
                response = client.complete_multipart_upload(
                    Bucket = os.environ['BUCKET'],
                    Key = FILENAME,
                    UploadId = UPLOADID,
                    MultipartUpload={
                        'Parts': PARTS
                    }
                )
                assert response
                STATUSCODE = 200
                STATUSTXT = 'Document recombined.'
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }
            except Exception as e:
                STATUSCODE = 500
                STATUSTXT = str(e)
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }

        # Delete parts if multipart upload completes or aborts.
        if ACTION == 'delete':
            try:
                response = client.delete_objects(
                    Bucket = os.environ['BUCKET'],
                    Delete={
                        'Objects': OBJECTS,
                        'Quiet': True
                    }
                )
                assert response
                STATUSCODE = 200
                STATUSTXT = 'Temporary file(s) deleted.'
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }
            except Exception as e:
                STATUSCODE = 500
                STATUSTXT = str(e)
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }

        # Purge documents from main storage.
        if ACTION == 'purge':
            try:
                response = client.delete_objects(
                    Bucket = os.environ['BUCKET'],
                    Delete={
                        'Objects': OBJECTS,
                        'Quiet': True
                    }
                )
                assert response
                STATUSCODE = 200
                STATUSTXT = 'Document purged.'
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }
            except Exception as e:
                STATUSCODE = 500
                STATUSTXT = str(e)
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }

        # Abort multipart upload if any part fails.
        if ACTION == 'abort':
            try:
                response = client.abort_multipart_upload(
                    Bucket = os.environ['BUCKET'],
                    Key = FILENAME,
                    UploadId = UPLOADID
                )
                assert response
                STATUSCODE = 200
                STATUSTXT = 'Multipart upload aborted.'
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }
            except Exception as e:
                STATUSCODE = 500
                STATUSTXT = str(e)
                logger.log( 'status_code', STATUSCODE)
                logger.log( 'status', STATUSTXT)
                print(json.dumps(logger.text))
                return {
                    'statusCode': STATUSCODE,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': os.environ['CORS']
                    },
                    'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
                }

    except Exception as e:
        STATUSCODE = 500
        STATUSTXT = str(e)
        logger.log( 'status_code', STATUSCODE)
        logger.log( 'status', STATUSTXT)
        print(json.dumps(logger.text))
        return {
            'statusCode': STATUSCODE,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': os.environ['CORS']
            },
            'body': '{{"status": "{}", "request_id": "{}", "status_code": {}}}'.format(STATUSTXT, context.aws_request_id, STATUSCODE)
        }
